	INSERT INTO Manufacturers(id, name, location) VALUES (1, 'Company_1', 'Moscow');
	INSERT INTO Manufacturers(id, name, location) VALUES (2, 'Company_2', 'Kazan');
	INSERT INTO Manufacturers(id, name, location) VALUES (3, 'Company_3', 'Vladivostok');
	INSERT INTO Manufacturers(id, name, location) VALUES (4, 'Company_4', 'Saratov');
	INSERT INTO Manufacturers(id, name, location) VALUES (5, 'Company_5', 'Moscow');
	INSERT INTO Manufacturers(id, name, location) VALUES (6, 'Company_6', 'Kazan');
	INSERT INTO Manufacturers(id, name, location) VALUES (7, 'Company_7', 'Vladivostok');
	INSERT INTO Manufacturers(id, name, location) VALUES (8, 'Company_8', 'Saratov');
	INSERT INTO Manufacturers(id, name, location) VALUES (9, 'Company_9', 'Moscow');
	INSERT INTO Manufacturers(id, name, location) VALUES (10, 'Company_10', 'Kazan');
	INSERT INTO Manufacturers(id, name, location) VALUES (11, 'Company_11', 'Vladivostok');
	INSERT INTO Manufacturers(id, name, location) VALUES (12, 'Company_12', 'Saratov');



	INSERT INTO Products(id,name,manufacturer_id) VALUES (1, 'Goods_1', '9');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (2, 'Goods_2', '8');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (3, 'Goods_3', '10');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (4, 'Goods_4', '3');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (5, 'Goods_5', '3');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (6, 'Goods_6', '5');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (7, 'Goods_7', '4');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (8, 'Goods_8', '2');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (9, 'Goods_9', '7');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (10, 'Goods_10', '6');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (11, 'Goods_11', '1');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (12, 'Goods_12', '5');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (13, 'Goods_13', '1');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (14, 'Goods_14', '10');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (15, 'Goods_15', '8');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (16, 'Goods_16', '1');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (17, 'Goods_17', '4');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (18, 'Goods_18', '5');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (19, 'Goods_19', '4');
	INSERT INTO Products(id,name,manufacturer_id) VALUES (20, 'Goods_20', '9');



	INSERT INTO Prices(id,value,product_id, discount) VALUES (1, 990, 1, 3);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (2, 1960, 2, 5);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (3, 2970, 3, 7);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (4, 3920, 4, 10);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (5, 4950, 5, 3);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (6, 5880, 6, 5);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (7, 6930, 7, 7);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (8, 7840, 8, 10);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (9, 8910, 9, 14);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (10, 9800, 10, 12);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (11, 10890, 11, 5);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (12, 11760, 12, 2);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (13, 12870, 13, 3);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (14, 13720, 14, 4);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (15, 14850, 15, 5);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (16, 15680, 16, 9);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (17, 16830, 17, 8);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (19, 18620, 19, 6);
	INSERT INTO Prices(id,value,product_id, discount) VALUES (20, 19800, 20, 10);
